package main

/**
 * add - a function that returns
 * the addition of two number
 */
func add(a, b int) int {
	return a + b
}

/**
 * sub - a function that returns
 * the subtraction of two number
 */
func sub(a, b int) int {
	return a - b
}

/**
 * mul - a function that returns
 * the multiplication of two number
 */
func mul(a, b int) int {
	return a * b
}

/**
 * div - a function that returns
 * the division of two number
 */
func div(a, b int) int {
	return a / b
}

/**
 * mod - a function that returns
 * the reminder of two number
 */
func mod(a, b int) int {
	return a % b
}
